
Trex.I.Processor.TridentStandardP = {

};
